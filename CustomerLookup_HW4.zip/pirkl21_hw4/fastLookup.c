#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "structs.h"

	DLList* head = NULL;

int main(int argc, char* argv[]){
	clock_t start_t, end_t, total1_t, total2_t;

	char *line = NULL;
	size_t len = 0;

   
  	 
	if(argc!=2){
		printf("wrong number of arguments. Usage ./fastLookup fileName\n");
		return -1;
	}
	start_t = clock();
		
	readFile(argv[1], &head);
	// Added extra Read function to read the file and creat the DLList
	end_t = clock();
   	printf("\nIt took = %ld seconds to load the file\n ", (double)(end_t - start_t) / CLOCKS_PER_SEC);

//  Create and load the DLLists into tree's //  
	printTree(head);
    TNode* nameTree = sortListName(head);
	TNode* phoneTree = sortListPhone(head);
	deleteTree(phoneTree);
	deleteTree(nameTree);
	
	printf("Welcome to the Fast Lookup Function!\n");
	printf("The following commands are the valid commands in the program:\n");
	printf("dn <customer last name> - deletes a customer by last name from the list.\n");
	printf("dp <phone number> - deletes a customer by Phone number from the list.\n");
	printf("sn <customer last name> - search for a customer by last name\n");
	printf("sp <phone number> - search for a customer by phone number\n");
	printf("qu - quit the flight tracker and deallocate the memory\n");
	printf("hm - bring up this information again\n");

	while(getline(&line, &len, stdin) != -1) {

		if(strlen(line) < 1) {
			continue;
		}
		if(parseCommandLine(line) == -1) break;
	}

	for(DLList* tmp = head; head != NULL; tmp = head) {

        freeCustomer(tmp->cust);
		head = head->next;
		free(tmp);
		

	}
	
	
/* TEST CODE FOR EACH DELETE/SEARCH FUNCTIONALITY 
	printf("\nTesting Delete Function: \n");
	deleteNode(&p, head->next);
	sortListPhone(p);	
	
	// reset p
	p = head;
	char * test = "Mockus";
	long int test2 = 483516370;
	printf("\nTesting Search By Name Function: \n");	
	searchForName(&p, test);
	printf("\nTesting Search By Phone Number Function: \n");
	searchForPhone(&p, test2); 
*/	
}

int parseCommandLine(char * temp) {

	char *arg1 = NULL;
	char *arg2 = NULL;
	char *arg3 = NULL;
	char *pos;
	if ((pos=strchr(temp, '\n')) != NULL) {
	   *pos = '\0';
	}
	
	if(strlen(temp) < 1) {
	printf("Error! Incorrect number of arguments.\n");
	return 0;
	}

		
	arg1 = strtok(temp, " \t");
	arg2 = strtok(NULL, " \t");
	arg3 = strtok(NULL, " \t");

		

	if((arg1 == NULL) || (strlen(arg1) != 2)) {
		printf("Error! Incorrect number of arguments.\n");
		return 0;
	}

	if(strcmp(arg1, "dn") == 0) {
		if(arg2 == NULL) {
			printf("Error! Missing Customer Name!\n");
			return 0;
		}
		// Delete Name
		DLList* tmp =  searchForName(head, arg2);
		if(tmp == NULL) return 0;
		deleteNode(&head, tmp);
    	TNode* nameTree = sortListName(head);
		TNode* phoneTree = sortListPhone(head);
		printTree(head);	
		deleteTree(phoneTree);
		deleteTree(nameTree);

	}else if(strcmp(arg1, "dp") == 0) {
		if(arg2 == NULL) {
			printf("Error! Missing Customer Phone!\n");
			return 0;
		}

		// Delete Phone 
		DLList* tmp1 =  searchForPhone(head, atoi(arg2));
		deleteNode(&head, tmp1);
    	TNode* nameTree = sortListName(head);
		TNode* phoneTree = sortListPhone(head);
		printTree(head);	
		deleteTree(phoneTree);
		deleteTree(nameTree);

	}else if(strcmp(arg1, "sn") == 0) {
		if(arg2 == NULL) {
			printf("Error! Please Provide Customer Name!\n");
			return 0;
		}

		// Search LName
    	TNode* nameTree = sortListName(head);
		searchBTreeLNameMain(nameTree, arg2);
		deleteTree(nameTree);
	
	}else if(strcmp(arg1, "sp") == 0) {
		if(arg2 == NULL) {
			printf("Error! Please Provide Customer Phone!\n");
			return 0;
		}

		// Search Phone
		TNode* phoneTree = sortListPhone(head);
		searchBTreePhoneMain(phoneTree, atoi(arg2));
		deleteTree(phoneTree);	
				

	}else if(strcmp(arg1, "qu") == 0) {
		// Exit
		return -1;
	}else if(strcmp(arg1, "hm") == 0) {
			
		// Help Menu	
	printf("Welcome to the Fast Lookup Function!\n");
	printf("The following commands are the valid commands in the program:\n");
	printf("dn <customer last name> - deletes a customer by last name from the list.\n");
	printf("dp <phone number> - deletes a customer by Phone number from the list.\n");
	printf("sn <customer last name> - search for a customer by last name\n");
	printf("sp <phone number> - search for a customer by phone number\n");
	printf("qu - quit the flight tracker and deallocate the memory\n");
	printf("hm - bring up this information again\n");

	}else {
		printf("\nThat's not a valid command.\n");
	}
	return 0;
}

int cmpfuncLName(const void* a, const void* b) {
	DLList *da = *((DLList **)a);
	DLList *db = *((DLList **)b);
	
	return strcmp(da->cust->lname, db->cust->lname);
}
int cmpfuncPhone(const void* a, const void* b) {
	DLList *da = *((DLList **)a);
	DLList *db = *((DLList **)b);
	if(da->cust->phone < db->cust->phone) return -1;
	else if (da->cust->phone == db->cust->phone) return 0;
	return 1;
}
