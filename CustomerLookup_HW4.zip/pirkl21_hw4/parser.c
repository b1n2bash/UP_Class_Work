#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"


const int LINE_LEN = 2000;

// prints all fields of the customer struct
void printCustomer(customer* t){
    if(t!=NULL)
        printf("\n Customer: %s %s\n Company: %s, Address: %s, City: %s\n County: %s, State: %s, Zip: %s\n Phone: %ld, Fax: %ld, Email: %s\n Web:%s \n-----\n",t->fname,
                                                    t->lname,
                                                    t->company,
                                                    t->address,
                                                    t->city,
                                                    t->county,
                                                    t->state,
                                                    t->zip,
                                                    t->phone,
                                                    t->fax,
                                                    t->email,
                                                    t->web);
}
/*
  parse a line from a file and load the customer object
  strtok - tokenizes the line
        the csv file has the delimiter -- "," since each field 
        starts and ends with " and individual fields are separated by , 
  strdup - used for char* fields, makes a memory copy of
           the tokenized fields (tokens) from stack to heap
*/
customer* parseLine(customer* t, char* line){
    const char* tokens;
    tokens = strtok(line, "\",\"");
    t->fname = strdup(tokens);
    tokens = strtok(NULL, "\",\"");
    t->lname = strdup(tokens);
    tokens = strtok(NULL, "\",\"");
    t->company = strdup(tokens);
    tokens = strtok(NULL, "\",\"");
    t->address = strdup(tokens);
    tokens = strtok(NULL, "\",\"");
    t->city = strdup(tokens);
    tokens = strtok(NULL, "\",\"");
    t->county = strdup(tokens);
    tokens = strtok(NULL, "\",\"");
    t->state = strdup(tokens);
    tokens = strtok(NULL, "\",\"");
    t->zip = strdup(tokens);
    tokens = strtok(NULL, "\",\"");
    t->phone = atoi(tokens);
    tokens = strtok(NULL, "\",\"");
    t->fax = atoi(tokens);
    tokens = strtok(NULL, "\",\"");
    t->email = strdup(tokens);
    tokens = strtok(NULL, "\",\"");
    t->web = strdup(tokens);
	
	if(t->fax < 0) {
		t->fax *= -1;
	}
	if(t->phone < 0) {
		t->phone *= -1;
	}

	if(t->fname == NULL) {
		t->fname = "Unknown";
	}
	if(t->lname == NULL) {
		t->lname = "Unknown";
	}
	if(t->company == NULL) {
		t->company = "Unknown";
	}
	if(t->address == NULL) {
		t->address = "Unknown";
	}
	if(t->city == NULL) {
		t->city = "Unknown";
	}
	if(t->county == NULL) {
		t->county = "Unknown";
	}
	if(t->state == NULL) {
		t->state = "Unknown";
	}
	if(t->zip == NULL) {
		t->zip = "Unknown";
	}
	if(t->email == NULL) {
		t->email = "Unknown";
	}
	if(t->web == NULL) {
		t->web = "Unknown";
	}
		
    return t;
}

void freeCustomer(customer* t){
    free(t->fname);
    free(t->lname);
    free(t->company);
    free(t->address);
    free(t->city);
    free(t->county);
    free(t->state);
    free(t->zip);
    free(t->email);
    free(t->web);
    free(t);
}

void readFile(char* fileName, DLList** head){

    FILE* fp = fopen(fileName, "r");
    if(fp==NULL){
        printf("Could not open file\n");
    }
    char line[LINE_LEN];                //temporary stack buffer to read lines into
    while (fgets(line, LINE_LEN, fp) != NULL){
		// DEBUG STATEMENT	printf("\nline = %s\n", line);
        customer* tmp = malloc(sizeof(struct customer));
        if(tmp == NULL){
            printf("Could not allocate memory for a customer\n");
        }
	    parseLine(tmp, line);
	    // printCustomer(tmp);
		push(head, tmp);
	}
	// Print the list before Sort
	// printList(*head);
    
	fclose(fp);
}

void push(DLList** headRef, customer* tmp) {
	// Allocate the Node
	DLList* tempNode = (DLList*) malloc(sizeof(DLList));
	// Copy the data stored at tmp to tempNode->cust, memcpy copies the struct's data
	tempNode->cust = tmp;
		
	// Set the DLLists Pointers
	tempNode->next = (*headRef);
	tempNode->prev = NULL;
		
		//  Change the prev of head node to new node
		if ((*headRef) != NULL) 
			(*headRef)->prev = tempNode;
		// Move the head node to point to the new node
		(*headRef) = tempNode;
}

void printList(DLList* nodeP) {

	DLList* last = NULL;
	while (nodeP != NULL) {
		printf(" %s,%ld\n", nodeP->cust->lname, nodeP->cust->phone);
		last = nodeP;
		nodeP = nodeP->next;
	}
}
