#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "structs.h"

/*
 *
 *
 * THE FOLLOWING FUNCTIONS ARE FOR THE PHONE TREE
 *  * CREATING THE TREE FROM AN ALREADY SORTED ARRAY 
 *  * Sorted Array to Balanced BST
 *  
 */


TNode* sortListName(DLList *pHead) {

	int count = 0;
	DLList **arr = NULL;
	DLList *p = pHead;

	for (count = 0; p; p = p->next) {
		++count;
	}

	DLList** arrayOfLName = (DLList **)malloc(sizeof(DLList*)*count);
	p = pHead;

		for (int i = 0; i < count; p = p->next, ++i) {
		arrayOfLName[i] = p;
	}
				// PRINT THE LNAME LIST		
	//	printf("\n======================================================================\n");
	//	printf("Before Sort: ");
		for (int i = 0; i < count; ++i) {
	//		printf("%s ", ((DLList *)arrayOfLName[i])->cust->lname);
		}
			
		qsort(arrayOfLName, count, sizeof(DLList*), cmpfuncLName);		
	
	//	printf("\nAfter Sort: ");
		for (int i = 0; i < count; ++i) {
	//		printf("%s ", ((DLList *)arrayOfLName[i])->cust->lname);
		}	
	//	printf("\n======================================================================\n");

			TNode* rootOfLNameTree = sortArrayToBST(arrayOfLName, 0, count - 1);			
			free(arrayOfLName);	
	
	return rootOfLNameTree;

} // End of sortList method


TNode* sortListPhone(DLList *pHead) {

	int count = 0;
	DLList **arr = NULL;
	DLList *p = pHead;

	for (count = 0; p; p = p->next) {
		++count;
	}

	DLList** arrayOfPhone = (DLList **)malloc(sizeof(DLList*)*count);
	p = pHead;

		for (int i = 0; i < count; p = p->next, ++i) {
		arrayOfPhone[i] = p;
	}
				// COMMENTED OUT PRINTLINES ARE FOR DEBUG
				// PRINT THE LPHONE LIST		
//		printf("\n======================================================================\n");
//		printf("Before Sort: ");
		for (int i = 0; i < count; ++i) {
	//			printf("%ld ", ((DLList *)arrayOfPhone[i])->cust->phone);
			}	
			
		qsort(arrayOfPhone, count, sizeof(DLList*), cmpfuncPhone);		
	
//		printf("\nAfter Sort: ");
		for (int i = 0; i < count; ++i) {
	//			printf("%ld ", ((DLList *)arrayOfPhone[i])->cust->phone);
			}	
//		printf("\n======================================================================\n");


			TNode* rootOfPhone = sortArrayToBST(arrayOfPhone, 0, count - 1);			
			//	preOrder(rootOfPhone);
			free(arrayOfPhone);
		return rootOfPhone;

}// End of sortListPhone method


// Beginning of sortArrayToBST Method
TNode* sortArrayToBST(DLList * arr[], int start, int end) {

	if (start > end) return NULL;

	int mid = (start + end)/2;
	TNode* root = newNode(arr[mid]);
	/* Recursively create the left and right subtree's */
	root->left = sortArrayToBST(arr, start, mid-1);
	root->right = sortArrayToBST(arr, mid+1, end);

	return root;
}


TNode* newNode(DLList * dLLData) {

		TNode* node = (TNode*)malloc(sizeof(TNode));
	
		node->data = dLLData;
		node->left = NULL;
		node->right = NULL;
	
		return node;
}

// headRef = pointer to head node pointer
// del = pointer to node to be deleted
void deleteNode(DLList** headRef, DLList* del) {

			// Base Case Scenario
		if(*headRef == NULL || del == NULL) return;

		/*If the node that we want to delete is the head */ 
		if(*headRef == del) 
				*headRef = del->next;

		/* Change next as long as the node to delete is NOT THE LAST NODE! */
		if(del->next != NULL)
			del->next->prev = del->prev;

		/* Change prev as long as the node to be deletes is not the first node! */
		if(del->prev != NULL)
			del->prev->next = del->next;
		
		/*FREE DEL!*/
		free(del);
		
}
// Reusable for delete calls. Will return an address to the node that can be passed as the node to delete.
DLList*  searchForName(DLList* head, char * lname) {
		int pos = 0;

		if(head==NULL) {
				printf("DLList Not Initialized");
				return NULL;
		}
	
		DLList * current = head;
			while(current != NULL) {
				pos++;
				if(strcmp(current->cust->lname, lname) == 0) {
						printf("\nCustomer Found: %s %s %ld %s\n", current->cust->fname, current->cust->lname, current->cust->phone, current->cust->email);
								return current;
				}
				
				if(current->next != NULL) {
						current = current->next;
				}else { break; }
			}
		printf("Customer %s does not exist in the list\n", lname);
		return NULL;	
}

// Reusable for delete calls. Will return an address to the node that can be passed as the node to delete.
DLList* searchForPhone(DLList* head, long int phone) {
		int pos = 0;

		if(head==NULL) {
				printf("DLList Not Initialized");
				return NULL;
		}
	
		DLList * current = head;
			while(current != NULL) {
				pos++;
				if(current->cust->phone == phone) {
						printf("\nPhone Number Found: %s %s %ld %s\n", current->cust->fname, current->cust->lname, current->cust->phone, current->cust->email);
								return current;
				}
				
				if(current->next != NULL) {
						current = current->next;
				}else { break; }
			}
		printf("Customer Phone: %ld does not exist in the list\n", phone);	
				return NULL;
}


// Delete the Tree
void deleteTree(TNode* t) {

	if(t == NULL) return;

	// Delete Both Subtree's
	deleteTree(t->left);
	deleteTree(t->right);

	// Delete the tree 
	free(t);

}

void printTree(DLList* head ) {
	
	DLList* p = head;
	printf("===========================================================\n");
	printf("List of Customers: \n");
	while(p) {

	printCustomer(p->cust);
	p = p->next;

	}
	printf("===========================================================\n");
}

/* ========================================================================== */
/* functions to search btree by last name */


/*
 * this function does a btree search by customers last name
 */
TNode * searchBTreeLName(TNode* root, char *lname) {

	
	// Base Cases: root is null or lname is present at root 
	if (root == NULL)
		 return root;
	
	if (strcmp(root->data->cust->lname, lname) == 0) 
		return root; 


	// lname is greater than root's lname 
	if (strcmp(root->data->cust->lname, lname) < 0) 
		return searchBTreeLName(root->right, lname); 

	// lname is smaller than root's lname 
	return searchBTreeLName(root->left, lname); 

}

/*
 * this function does a btree search by customers last name and outputs duration
 */
TNode * searchBTreeLNameMain(TNode* root, char *lname) {

	TNode *tmp;
	clock_t start_t;
	clock_t  end_t;

	start_t = clock();
	tmp =  searchBTreeLName(root, lname);
	end_t = clock();
   	
	if(tmp == NULL) {
		printf("Name Not Found!\n");
		return NULL;
	}
	printCustomer(tmp->data->cust);
	printf("\nIt took = %f seconds to search the file by Name\n ", (end_t - start_t));  /* / CLOCKS_PER_SEC); */
	return tmp;

}

/* ========================================================================== */
/* functions to search btree by phone number */


/*
 * this function does a btree search by customers phone number
 */
TNode *searchBTreePhone(TNode* root, long int phone) {

	// Base Cases: root is null or phone is present at root 
	if (root == NULL) return root;
	
	if (root->data->cust->phone == phone) 
		return root; 

	if (root->data->cust->phone > phone) 
		return searchBTreePhone(root->left, phone); 

	// phone is smaller than root's phone 
	return searchBTreePhone(root->right, phone); 

}


/*
 * this function does a btree search by customers phone number and outputs duration
 */
TNode * searchBTreePhoneMain(TNode* root, long int phone) {

	clock_t start_t;
	clock_t  end_t;

	start_t = clock();
	TNode *tmp =  searchBTreePhone(root, phone);
	if(tmp == NULL) {
		printf("Phone Number Not Found!\n");
		return NULL;
	}
	end_t = clock();
	printCustomer(tmp->data->cust);
	printf("start_t: %f\n", start_t);
	printf("\nIt took = %f seconds to search the file by Phone\n ", (end_t - start_t)); /* / CLOCKS_PER_SEC); */

	return tmp;

}



