#ifndef STRUCTS
#define STRUCTS


typedef struct customer{
    char* fname;
    char* lname;
    char* company;
    char* address;
    char* city;
    char* county;
    char* state;
    char* zip;
    long int phone;
    long int fax;
    char* email;
    char* web;
}customer;

typedef struct DLList {
	struct DLList* next;
	struct DLList* prev;
	
	customer *cust;

}DLList;


typedef struct TNode{
	 struct TNode* right;
     struct TNode* left;
    union {
        char* lname;
        long int phone;
    };
   DLList* data;

}TNode;

#endif
// Main Function / Command Parsing: _
int parseCommandLine(char * temp);
void freeCustomer(customer* t);


// Search the DLList for a specific Customer
DLList* searchForPhone(DLList* head, long int);
DLList*  searchForName(DLList* head, char * lname);

// Search the Tree
TNode * searchBTreeLNameMain(TNode* root, char *lname);
TNode * searchBTreePhoneMain(TNode* root, long int phone); 
TNode *searchBTreePhone(TNode* root, long int phone);
TNode * searchBTreeLName(TNode* root, char *lname);

// Sorted Array to Binary Search Tree:
TNode* sortArrayToBST(DLList * arr[], int start, int end);

// Sort The DLLists
TNode* sortListName(DLList *pHead);
TNode* sortListPhone(DLList *pHead);

// Deleting from a DLList
void deleteNode(DLList** headRef, DLList* del);

// The Print Functions X X
void printDLList(DLList *);
void printCustomer(customer* t);
void printTree(DLList* head);

// Qsort CMP Functions X X 
int cmpfuncLName(const void* a, const void* b);
int cmpfuncPhone(const void* a, const void* b);

// Creating the Tree's
TNode* newNode(DLList*);

// Push the values into the DLList
void push(DLList** headRef, customer*);
void printList(DLList* nodeP);

// Quit the function and deallocate the memory
void deleteTree(TNode* t);
	
// File Parsing X
customer* parseLine(customer*, char*);

// Read File X
void readFile(char*, DLList**); 
